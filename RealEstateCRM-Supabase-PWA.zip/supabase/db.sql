
-- Enable needed extensions
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- Org table
create table public.orgs (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

-- User profile: 1-1 with auth.users, ties user to an org and role
create table public.user_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  org_id uuid references public.orgs(id) on delete set null,
  role text not null default 'agent' check (role in ('admin','agent')),
  full_name text,
  created_at timestamptz not null default now()
);

-- Leads
create table public.leads (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  owner_id uuid references auth.users(id) on delete set null,
  name text not null,
  phone text,
  email text,
  source text,
  status text not null default 'new' check (status in ('new','contacted','visiting','negotiation','won','lost')),
  budget numeric,
  location text,
  notes text,
  next_followup_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Updated-at trigger
create or replace function public.trigger_set_timestamp()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists leads_updated_at on public.leads;
create trigger leads_updated_at
before update on public.leads
for each row execute procedure public.trigger_set_timestamp();

-- RLS
alter table public.orgs enable row level security;
alter table public.user_profiles enable row level security;
alter table public.leads enable row level security;

-- Policies

-- Orgs: members of org can read their org
drop policy if exists "org members read own org" on public.orgs;
create policy "org members read own org"
on public.orgs for select
using (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid()
      and up.org_id = orgs.id
  )
);

-- user_profiles
drop policy if exists "own profile read" on public.user_profiles;
create policy "own profile read"
on public.user_profiles for select
using (user_id = auth.uid());

drop policy if exists "own profile update" on public.user_profiles;
create policy "own profile update"
on public.user_profiles for update
using (user_id = auth.uid());

drop policy if exists "org admin read profiles" on public.user_profiles;
create policy "org admin read profiles"
on public.user_profiles for select
using (
  exists (
    select 1 from public.user_profiles me
    where me.user_id = auth.uid()
      and me.org_id = user_profiles.org_id
      and me.role = 'admin'
  )
);

-- Leads policies
drop policy if exists "org members read leads" on public.leads;
create policy "org members read leads"
on public.leads for select
using (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid()
      and up.org_id = leads.org_id
  )
);

drop policy if exists "org members insert leads" on public.leads;
create policy "org members insert leads"
on public.leads for insert
with check (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid()
      and up.org_id = leads.org_id
  )
);

drop policy if exists "owner or admin update leads" on public.leads;
create policy "owner or admin update leads"
on public.leads for update
using (
  (owner_id = auth.uid())
  or exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid()
      and up.org_id = leads.org_id
      and up.role = 'admin'
  )
);

drop policy if exists "admin delete leads" on public.leads;
create policy "admin delete leads"
on public.leads for delete
using (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid()
      and up.org_id = leads.org_id
      and up.role = 'admin'
  )
);

-- RPC to initialize a user's org/admin profile (run once)
create or replace function public.init_user(org_name text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  prof_count int;
  new_org_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  select count(*) into prof_count from public.user_profiles where user_id = auth.uid();
  if prof_count = 0 then
    insert into public.orgs(name) values (coalesce(org_name, 'My Team')) returning id into new_org_id;
    insert into public.user_profiles(user_id, org_id, role) values (auth.uid(), new_org_id, 'admin');
  end if;
end;
$$;

-- Helpful indices
create index if not exists leads_org_status_idx on public.leads(org_id, status);
create index if not exists leads_followup_idx on public.leads(next_followup_at);
create index if not exists leads_owner_idx on public.leads(owner_id);
