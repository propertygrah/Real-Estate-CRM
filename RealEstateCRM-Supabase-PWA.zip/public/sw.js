
self.addEventListener('install', (e) => {
  self.skipWaiting();
});
self.addEventListener('activate', (e) => {
  self.clients.claim();
});
// Basic offline fallback cache (optional minimal)
const CACHE = 'crm-cache-v1';
const OFFLINE_URLS = ['/', '/leads', '/import', '/tasks'];
self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  event.respondWith(
    caches.open(CACHE).then(async (cache) => {
      const cached = await cache.match(request);
      if (cached) return cached;
      try {
        const fresh = await fetch(request);
        if (fresh && fresh.status === 200 && fresh.type === 'basic') {
          cache.put(request, fresh.clone());
        }
        return fresh;
      } catch (err) {
        // Try offline fallbacks for navigations
        if (request.mode === 'navigate') {
          const home = await cache.match('/');
          if (home) return home;
        }
        throw err;
      }
    })
  );
});
