
'use client';

import { createClient } from '@supabase/supabase-js';
import { useEffect, useState } from 'react';
import Link from 'next/link';

type Lead = {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  source: string | null;
  status: 'new'|'contacted'|'visiting'|'negotiation'|'won'|'lost';
  budget: number | null;
  location: string | null;
  notes: string | null;
  next_followup_at: string | null;
};

const STATUS = ['new','contacted','visiting','negotiation','won','lost'] as const;

export default function LeadsPage() {
  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    let query = supabase.from('leads').select('*').order('created_at', { ascending: false }).limit(500);
    if (q.trim()) query = query.ilike('name', `%${q}%`);
    const { data, error } = await query;
    if (!error && data) setLeads(data as any);
    setLoading(false);
  };

  useEffect(()=>{ load(); }, []);

  const quickStatus = async (id: string, status: Lead['status']) => {
    await supabase.from('leads').update({ status }).eq('id', id);
    await load();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <input className="input" placeholder="Search by name…" value={q} onChange={e=>setQ(e.target.value)} />
        <button className="btn" onClick={load}>Search</button>
        <Link href="/leads/new" className="btn btn-primary ml-auto">+ New Lead</Link>
      </div>
      <div className="card overflow-auto">
        {loading ? <div>Loading…</div> :
        <table className="table">
          <thead>
            <tr>
              <th>Name</th><th>Phone</th><th>Source</th><th>Status</th><th>Budget</th><th>Next Follow-up</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {leads.map(l => (
              <tr key={l.id}>
                <td className="font-medium">{l.name}</td>
                <td>{l.phone ?? ''}</td>
                <td><span className="badge">{l.source ?? ''}</span></td>
                <td>
                  <select className="select" value={l.status} onChange={e=>quickStatus(l.id, e.target.value as any)}>
                    {STATUS.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </td>
                <td>{l.budget ?? ''}</td>
                <td>{l.next_followup_at ? new Date(l.next_followup_at).toLocaleString() : ''}</td>
                <td className="space-x-2">
                  <Link className="btn" href={`/leads/${l.id}`}>Open</Link>
                  {l.phone ? <a className="btn" href={`https://wa.me/91${l.phone.replace(/\D/g,'')}`} target="_blank">WhatsApp</a> : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>}
      </div>
    </div>
  );
}
