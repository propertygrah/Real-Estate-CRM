
'use client';

import { createClient } from '@supabase/supabase-js';
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';

export default function LeadDetail() {
  const { id } = useParams<{id: string}>();
  const router = useRouter();
  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);

  const [lead, setLead] = useState<any>(null);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    const { data } = await supabase.from('leads').select('*').eq('id', id).single();
    setLead(data);
  };

  useEffect(()=>{ load(); }, [id]);

  const save = async () => {
    setSaving(true);
    const { error } = await supabase.from('leads').update(lead).eq('id', id);
    setSaving(false);
    if (!error) router.push('/leads');
  };

  if (!lead) return <div>Loading…</div>;

  return (
    <div className="max-w-2xl card space-y-3">
      <h2 className="text-lg font-semibold">Edit Lead</h2>
      {['name','phone','email','source','location'].map((k)=> (
        <div key={k}>
          <div className="label capitalize">{k}</div>
          <input className="input" value={lead[k] ?? ''} onChange={e=>setLead({ ...lead, [k]: e.target.value })} />
        </div>
      ))}
      <div>
        <div className="label">Budget</div>
        <input type="number" className="input" value={lead.budget ?? ''} onChange={e=>setLead({ ...lead, budget: e.target.value ? Number(e.target.value) : null })} />
      </div>
      <div>
        <div className="label">Status</div>
        <select className="select" value={lead.status} onChange={e=>setLead({ ...lead, status: e.target.value })}>
          {['new','contacted','visiting','negotiation','won','lost'].map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>
      <div>
        <div className="label">Next Follow-up</div>
        <input type="datetime-local" className="input"
          value={lead.next_followup_at ? new Date(lead.next_followup_at).toISOString().slice(0,16) : ''}
          onChange={e=>setLead({ ...lead, next_followup_at: e.target.value ? new Date(e.target.value).toISOString() : null })}
        />
      </div>
      <div>
        <div className="label">Notes</div>
        <textarea className="input" rows={4} value={lead.notes ?? ''} onChange={e=>setLead({ ...lead, notes: e.target.value })} />
      </div>
      <div className="flex gap-2">
        <button className="btn btn-primary" onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
        <button className="btn" onClick={()=>router.push('/leads')}>Cancel</button>
      </div>
    </div>
  );
}
