
'use client';

import { createClient } from '@supabase/supabase-js';
import { useState } from 'react';

export default function AuthPage() {
  const [email, setEmail] = useState('');
  const [info, setInfo] = useState('');
  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);

  const signIn = async () => {
    const { error } = await supabase.auth.signInWithOtp({ email });
    if (error) setInfo(error.message); else setInfo('Check your email for a magic link.');
  };

  const initUser = async () => {
    const { data, error } = await supabase.rpc('init_user', { org_name: 'PropertyGrah' });
    if (error) setInfo(error.message); else setInfo('Initialized! You are admin of your org.');
  };

  return (
    <div className="max-w-md card space-y-3">
      <h2 className="text-lg font-semibold">Sign in</h2>
      <input className="input" placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)} />
      <button className="btn btn-primary" onClick={signIn}>Send Magic Link</button>
      <div className="text-sm text-slate-600">After signing in, click below once:</div>
      <button className="btn" onClick={initUser}>Create Org & Profile (RPC)</button>
      <div className="text-sm text-slate-600">{info}</div>
    </div>
  );
}
