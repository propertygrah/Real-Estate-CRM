
'use client';

import Papa from 'papaparse';
import { createClient } from '@supabase/supabase-js';
import { useState } from 'react';

export default function ImportPage() {
  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
  const [log, setLog] = useState<string>('');

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    Papa.parse(file, {
      header: true,
      complete: async (res) => {
        const rows = (res.data as any[]).filter(Boolean).slice(0, 1000);
        const { error } = await supabase.from('leads').insert(rows.map(r => ({
          name: r.name || r.Name,
          phone: r.phone || r.Phone || r.mobile,
          email: r.email || r.Email,
          source: r.source || r.Source,
          location: r.location || r.Location,
          budget: r.budget ? Number(r.budget) : null,
          status: (r.status || 'new').toLowerCase()
        })));
        setLog(error ? error.message : `Imported ${rows.length} rows.`);
      }
    });
  };

  return (
    <div className="card space-y-3 max-w-xl">
      <h2 className="text-lg font-semibold">CSV Import</h2>
      <p className="text-sm text-slate-600">Columns supported: name, phone, email, source, location, budget, status</p>
      <input type="file" accept=".csv" onChange={handleFile} />
      <div className="text-sm text-slate-700">{log}</div>
    </div>
  );
}
