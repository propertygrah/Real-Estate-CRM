
import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "Real Estate CRM",
  description: "Supabase + Next.js CRM for Real Estate teams"
}

import SWRegister from "@/components/sw-register";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover"/>
        <meta name="apple-mobile-web-app-capable" content="yes"/>
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
        <link rel="manifest" href="/manifest.webmanifest"/>
        <link rel="apple-touch-icon" href="/icons/icon-192.png"/>
      </head>
      <body>
        <div className="border-b bg-white">
          <div className="container flex items-center gap-4 py-3">
            <Link href="/" className="font-semibold">🏠 Real Estate CRM</Link>
            <nav className="flex gap-3 text-sm">
              <Link href="/leads">Leads</Link>
              <Link href="/import">Import</Link>
              <Link href="/tasks">Reminders</Link>
            </nav>
            <div className="ml-auto">
              <a href="/auth" className="btn">Sign In</a>
            </div>
          </div>
        </div>
        <div className="container py-6">{children}</div>
              <SWRegister />
      </body>
    </html>
  );
}
