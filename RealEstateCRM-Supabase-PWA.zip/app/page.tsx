
import Link from "next/link";

export default function Page() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Welcome 👋</h2>
        <p className="text-sm text-slate-600">
          This CRM lets your team capture leads, track visits, and set reminders with Row Level Security.
        </p>
        <div className="mt-4 flex gap-2">
          <Link href="/leads" className="btn btn-primary">Open Leads</Link>
          <Link href="/import" className="btn">Import CSV</Link>
        </div>
      </div>
      <div className="card">
        <h3 className="font-semibold mb-2">Quick Tips</h3>
        <ul className="list-disc pl-5 text-sm text-slate-700 space-y-1">
          <li>Sign in, then run <code>init_user</code> RPC once from /auth page to create your org & admin profile.</li>
          <li>Every lead belongs to an org. Policies ensure agents see only their org’s data.</li>
          <li>Use the status funnel: new → contacted → visiting → negotiation → won/lost.</li>
        </ul>
      </div>
    </div>
  );
}
