
'use client';

import { createClient } from '@supabase/supabase-js';
import { useEffect, useState } from 'react';

export default function TasksPage() {
  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
  const [rows, setRows] = useState<any[]>([]);

  const load = async () => {
    const now = new Date().toISOString();
    const { data } = await supabase.from('leads')
      .select('id,name,phone,next_followup_at,status')
      .lte('next_followup_at', now)
      .order('next_followup_at', { ascending: true });
    setRows(data || []);
  };

  useEffect(()=>{ load(); }, []);

  return (
    <div className="card">
      <h2 className="text-lg font-semibold mb-2">Due & Overdue Follow-ups</h2>
      <table className="table">
        <thead><tr><th>Name</th><th>Phone</th><th>When</th><th>Status</th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}>
              <td>{r.name}</td>
              <td>{r.phone ?? ''}</td>
              <td>{r.next_followup_at ? new Date(r.next_followup_at).toLocaleString() : ''}</td>
              <td><span className="badge">{r.status}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
